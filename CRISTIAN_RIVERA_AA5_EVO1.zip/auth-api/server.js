/**
 * Servidor principal de la API REST de autenticación
 * Tecnologías: Node.js, Express, MongoDB
 */

// Importar dependencias
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const dotenv = require('dotenv');
const connectDB = require('./src/config/database');

// Cargar variables de entorno
dotenv.config();

// Importar rutas
const authRoutes = require('./src/routes/auth');

// Crear instancia de Express
const app = express();

// Conectar a la base de datos
connectDB();

// Middlewares de seguridad y configuración
app.use(helmet()); // Establece headers de seguridad
app.use(cors()); // Habilita CORS para todas las rutas
app.use(express.json({ limit: '10mb' })); // Parser JSON con límite
app.use(express.urlencoded({ extended: true })); // Parser URL encoded

// Middleware para logging de requests
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);
    next();
});

// Rutas principales
app.use('/api/auth', authRoutes);

// Ruta de prueba
app.get('/', (req, res) => {
    res.json({
        message: 'API de Autenticación funcionando correctamente',
        version: '1.0.0',
        endpoints: {
            register: 'POST /api/auth/register',
            login: 'POST /api/auth/login',
            profile: 'GET /api/auth/profile'
        }
    });
});

// Middleware para rutas no encontradas
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Ruta no encontrada'
    });
});

// Middleware global de manejo de errores
app.use((error, req, res, next) => {
    console.error('Error:', error.message);
    res.status(500).json({
        success: false,
        message: 'Error interno del servidor',
        error: process.env.NODE_ENV === 'development' ? error.message : undefined
    });
});

// Configurar puerto
const PORT = process.env.PORT || 3000;

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor ejecutándose en puerto ${PORT}`);
    console.log(`📍 URL: http://localhost:${PORT}`);
    console.log(`🌍 Entorno: ${process.env.NODE_ENV || 'development'}`);
});

// Manejo de errores no capturados
process.on('unhandledRejection', (err) => {
    console.error('Error no manejado:', err.message);
    process.exit(1);
});

process.on('uncaughtException', (err) => {
    console.error('Excepción no capturada:', err.message);
    process.exit(1);
});
