/**
 * Rutas de autenticación
 * Define endpoints para registro, login y operaciones de usuario
 */

const express = require('express');
const { register, login, getProfile } = require('../controllers/authController');
const { authenticateToken } = require('../middleware/auth');

// Crear router
const router = express.Router();

/**
 * @route   POST /api/auth/register
 * @desc    Registrar nuevo usuario
 * @access  Público
 * @body    { username, email, password }
 */
router.post('/register', register);

/**
 * @route   POST /api/auth/login
 * @desc    Iniciar sesión
 * @access  Público
 * @body    { username, password }
 */
router.post('/login', login);

/**
 * @route   GET /api/auth/profile
 * @desc    Obtener perfil del usuario autenticado
 * @access  Privado (requiere token)
 * @header  Authorization: Bearer <token>
 */
router.get('/profile', authenticateToken, getProfile);

/**
 * @route   GET /api/auth/test
 * @desc    Endpoint de prueba para verificar autenticación
 * @access  Privado (requiere token)
 */
router.get('/test', authenticateToken, (req, res) => {
    res.json({
        success: true,
        message: 'Token válido',
        data: {
            userId: req.userId,
            username: req.user.username,
            timestamp: new Date().toISOString()
        }
    });
});

module.exports = router;
