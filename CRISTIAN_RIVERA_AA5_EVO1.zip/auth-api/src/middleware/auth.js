/**
 * Middleware de autenticación JWT
 * Verifica tokens de acceso en rutas protegidas
 */

const jwt = require('jsonwebtoken');
const User = require('../models/User');

/**
 * Middleware para verificar token JWT
 * Protege rutas que requieren autenticación
 */
const authenticateToken = async (req, res, next) => {
    try {
        // Obtener token del header Authorization
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

        // Verificar si el token existe
        if (!token) {
            return res.status(401).json({
                success: false,
                message: 'Token de acceso requerido'
            });
        }

        // Verificar y decodificar el token
        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Verificar si el usuario existe
        const user = await User.findById(decoded.userId);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Token inválido: usuario no encontrado'
            });
        }

        // Verificar si el usuario está activo
        if (!user.isActive) {
            return res.status(401).json({
                success: false,
                message: 'Cuenta desactivada'
            });
        }

        // Añadir información del usuario a la request
        req.userId = decoded.userId;
        req.user = user;

        // Continuar al siguiente middleware
        next();

    } catch (error) {
        console.error('Error en autenticación:', error.message);

        // Manejo específico de errores JWT
        if (error.name === 'JsonWebTokenError') {
            return res.status(401).json({
                success: false,
                message: 'Token inválido'
            });
        }

        if (error.name === 'TokenExpiredError') {
            return res.status(401).json({
                success: false,
                message: 'Token expirado'
            });
        }

        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
};

/**
 * Middleware opcional para verificar token
 * No bloquea la request si no hay token válido
 */
const optionalAuth = async (req, res, next) => {
    try {
        const authHeader = req.headers['authorization'];
        const token = authHeader && authHeader.split(' ')[1];

        if (token) {
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await User.findById(decoded.userId);
            
            if (user && user.isActive) {
                req.userId = decoded.userId;
                req.user = user;
            }
        }

        next();
    } catch (error) {
        // En auth opcional, continuamos sin bloquear
        next();
    }
};

module.exports = {
    authenticateToken,
    optionalAuth
};
