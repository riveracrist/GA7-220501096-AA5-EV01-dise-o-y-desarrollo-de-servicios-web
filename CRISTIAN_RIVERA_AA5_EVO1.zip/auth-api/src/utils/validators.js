/**
 * Utilidades de validación para la API
 * Contiene funciones para validar datos de entrada
 */

/**
 * Validar datos de registro
 * @param {object} data - Datos a validar
 * @returns {object} - Resultado de validación
 */
const validateRegister = (data) => {
    const errors = [];
    const { username, email, password } = data;

    // Validar username
    if (!username || username.trim().length === 0) {
        errors.push('El nombre de usuario es obligatorio');
    } else if (username.trim().length < 3) {
        errors.push('El nombre de usuario debe tener al menos 3 caracteres');
    } else if (username.trim().length > 30) {
        errors.push('El nombre de usuario no puede exceder 30 caracteres');
    } else if (!/^[a-zA-Z0-9_]+$/.test(username.trim())) {
        errors.push('El nombre de usuario solo puede contener letras, números y guiones bajos');
    }

    // Validar email
    if (!email || email.trim().length === 0) {
        errors.push('El email es obligatorio');
    } else if (!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email.trim())) {
        errors.push('Formato de email inválido');
    }

    // Validar password
    if (!password || password.length === 0) {
        errors.push('La contraseña es obligatoria');
    } else if (password.length < 6) {
        errors.push('La contraseña debe tener al menos 6 caracteres');
    } else if (password.length > 100) {
        errors.push('La contraseña no puede exceder 100 caracteres');
    }

    return {
        isValid: errors.length === 0,
        errors
    };
};

/**
 * Validar datos de login
 * @param {object} data - Datos a validar
 * @returns {object} - Resultado de validación
 */
const validateLogin = (data) => {
    const errors = [];
    const { username, password } = data;

    // Validar username/email
    if (!username || username.trim().length === 0) {
        errors.push('El usuario o email es obligatorio');
    }

    // Validar password
    if (!password || password.length === 0) {
        errors.push('La contraseña es obligatoria');
    }

    return {
        isValid: errors.length === 0,
        errors
    };
};

/**
 * Validar formato de email
 * @param {string} email - Email a validar
 * @returns {boolean} - True si es válido
 */
const isValidEmail = (email) => {
    return /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email);
};

/**
 * Validar fortaleza de contraseña
 * @param {string} password - Contraseña a validar
 * @returns {object} - Resultado de validación
 */
const validatePasswordStrength = (password) => {
    const checks = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /\d/.test(password),
        special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
    };

    const score = Object.values(checks).filter(Boolean).length;
    
    return {
        isStrong: score >= 4,
        score,
        checks,
        suggestions: {
            length: !checks.length ? 'Usar al menos 8 caracteres' : null,
            uppercase: !checks.uppercase ? 'Incluir al menos una letra mayúscula' : null,
            lowercase: !checks.lowercase ? 'Incluir al menos una letra minúscula' : null,
            number: !checks.number ? 'Incluir al menos un número' : null,
            special: !checks.special ? 'Incluir al menos un carácter especial' : null
        }
    };
};

module.exports = {
    validateRegister,
    validateLogin,
    isValidEmail,
    validatePasswordStrength
};
