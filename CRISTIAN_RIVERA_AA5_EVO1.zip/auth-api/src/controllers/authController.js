/**
 * Controlador de Autenticación
 * Maneja la lógica de registro, login y operaciones de usuario
 */

const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { validateRegister, validateLogin } = require('../utils/validators');

/**
 * Generar token JWT
 * @param {string} userId - ID del usuario
 * @returns {string} - Token JWT
 */
const generateToken = (userId) => {
    return jwt.sign(
        { userId }, 
        process.env.JWT_SECRET,
        { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );
};

/**
 * Registrar nuevo usuario
 * POST /api/auth/register
 */
const register = async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Validar datos de entrada
        const validation = validateRegister(req.body);
        if (!validation.isValid) {
            return res.status(400).json({
                success: false,
                message: 'Datos de entrada inválidos',
                errors: validation.errors
            });
        }

        // Verificar si el usuario ya existe
        const existingUser = await User.findOne({
            $or: [
                { email: email.toLowerCase() },
                { username: username.toLowerCase() }
            ]
        });

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: 'El usuario o email ya existe'
            });
        }

        // Crear nuevo usuario
        const newUser = new User({
            username: username.toLowerCase(),
            email: email.toLowerCase(),
            password
        });

        // Guardar usuario en base de datos
        await newUser.save();

        // Generar token
        const token = generateToken(newUser._id);

        // Respuesta exitosa
        res.status(201).json({
            success: true,
            message: 'Usuario registrado exitosamente',
            data: {
                user: newUser.toPublicJSON(),
                token
            }
        });

        console.log(`✅ Usuario registrado: ${username}`);

    } catch (error) {
        console.error('Error en registro:', error);
        
        // Manejo de errores de validación de MongoDB
        if (error.name === 'ValidationError') {
            const errors = Object.values(error.errors).map(err => err.message);
            return res.status(400).json({
                success: false,
                message: 'Error de validación',
                errors
            });
        }

        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
};

/**
 * Iniciar sesión
 * POST /api/auth/login
 */
const login = async (req, res) => {
    try {
        const { username, password } = req.body;

        // Validar datos de entrada
        const validation = validateLogin(req.body);
        if (!validation.isValid) {
            return res.status(400).json({
                success: false,
                message: 'Datos de entrada inválidos',
                errors: validation.errors
            });
        }

        // Buscar usuario por username o email
        const user = await User.findOne({
            $or: [
                { username: username.toLowerCase() },
                { email: username.toLowerCase() }
            ]
        });

        // Verificar si el usuario existe
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Credenciales incorrectas'
            });
        }

        // Verificar si el usuario está activo
        if (!user.isActive) {
            return res.status(401).json({
                success: false,
                message: 'Cuenta desactivada. Contacta al administrador'
            });
        }

        // Verificar contraseña
        const isPasswordValid = await user.comparePassword(password);
        if (!isPasswordValid) {
            return res.status(401).json({
                success: false,
                message: 'Credenciales incorrectas'
            });
        }

        // Generar token
        const token = generateToken(user._id);

        // Respuesta exitosa
        res.json({
            success: true,
            message: 'Autenticación satisfactoria',
            data: {
                user: user.toPublicJSON(),
                token
            }
        });

        console.log(`✅ Login exitoso: ${user.username}`);

    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
};

/**
 * Obtener perfil del usuario autenticado
 * GET /api/auth/profile
 */
const getProfile = async (req, res) => {
    try {
        // El usuario viene del middleware de autenticación
        const user = await User.findById(req.userId);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'Usuario no encontrado'
            });
        }

        res.json({
            success: true,
            message: 'Perfil obtenido exitosamente',
            data: {
                user: user.toPublicJSON()
            }
        });

    } catch (error) {
        console.error('Error obteniendo perfil:', error);
        res.status(500).json({
            success: false,
            message: 'Error interno del servidor'
        });
    }
};

module.exports = {
    register,
    login,
    getProfile
};
