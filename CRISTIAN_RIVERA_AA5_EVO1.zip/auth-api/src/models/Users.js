/**
 * Modelo de Usuario para MongoDB usando Mongoose
 * Define el esquema y métodos para la entidad User
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

/**
 * Esquema del usuario
 */
const userSchema = new mongoose.Schema({
    // Nombre de usuario único
    username: {
        type: String,
        required: [true, 'El nombre de usuario es obligatorio'],
        unique: true,
        trim: true,
        minlength: [3, 'El nombre de usuario debe tener al menos 3 caracteres'],
        maxlength: [30, 'El nombre de usuario no puede exceder 30 caracteres'],
        match: [/^[a-zA-Z0-9_]+$/, 'El nombre de usuario solo puede contener letras, números y guiones bajos']
    },

    // Email único
    email: {
        type: String,
        required: [true, 'El email es obligatorio'],
        unique: true,
        trim: true,
        lowercase: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'Formato de email inválido']
    },

    // Contraseña encriptada
    password: {
        type: String,
        required: [true, 'La contraseña es obligatoria'],
        minlength: [6, 'La contraseña debe tener al menos 6 caracteres']
    },

    // Fecha de registro
    createdAt: {
        type: Date,
        default: Date.now
    },

    // Fecha de última actualización
    updatedAt: {
        type: Date,
        default: Date.now
    },

    // Estado del usuario
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    // Configuraciones del esquema
    timestamps: true, // Añade createdAt y updatedAt automáticamente
    versionKey: false // Elimina el campo __v
});

/**
 * Middleware pre-save para encriptar contraseña
 * Se ejecuta antes de guardar el documento
 */
userSchema.pre('save', async function(next) {
    // Solo encriptar si la contraseña fue modificada
    if (!this.isModified('password')) {
        return next();
    }

    try {
        // Generar salt y encriptar contraseña
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

/**
 * Método para comparar contraseñas
 * @param {string} candidatePassword - Contraseña a verificar
 * @returns {boolean} - True si coincide, false si no
 */
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

/**
 * Método para obtener información pública del usuario
 * @returns {object} - Datos públicos del usuario
 */
userSchema.methods.toPublicJSON = function() {
    return {
        id: this._id,
        username: this.username,
        email: this.email,
        createdAt: this.createdAt,
        isActive: this.isActive
    };
};

/**
 * Índices para optimizar consultas
 */
userSchema.index({ username: 1 });
userSchema.index({ email: 1 });
userSchema.index({ createdAt: -1 });

module.exports = mongoose.model('User', userSchema);
