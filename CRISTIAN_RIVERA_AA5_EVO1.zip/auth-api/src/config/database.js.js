/**
 * Configuración de conexión a MongoDB
 * Utiliza Mongoose como ODM
 */

const mongoose = require('mongoose');

/**
 * Conectar a la base de datos MongoDB
 * @returns {Promise} Promesa de conexión
 */
const connectDB = async () => {
    try {
        // Opciones de conexión
        const options = {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            maxPoolSize: 10, // Máximo 10 conexiones en el pool
            serverSelectionTimeoutMS: 5000, // Timeout de selección del servidor
            socketTimeoutMS: 45000, // Timeout del socket
        };

        // Realizar conexión
        const connection = await mongoose.connect(process.env.MONGODB_URI, options);
        
        console.log(`✅ MongoDB conectado: ${connection.connection.host}`);
        console.log(`📊 Base de datos: ${connection.connection.name}`);

    } catch (error) {
        console.error('❌ Error conectando a MongoDB:', error.message);
        process.exit(1); // Terminar proceso si no se puede conectar
    }
};

// Manejo de eventos de conexión
mongoose.connection.on('connected', () => {
    console.log('🔗 Mongoose conectado a MongoDB');
});

mongoose.connection.on('error', (error) => {
    console.error('❌ Error de conexión MongoDB:', error);
});

mongoose.connection.on('disconnected', () => {
    console.log('🔌 Mongoose desconectado de MongoDB');
});

// Manejo de cierre de aplicación
process.on('SIGINT', async () => {
    await mongoose.connection.close();
    console.log('🔌 Conexión MongoDB cerrada por terminación de aplicación');
    process.exit(0);
});

module.exports = connectDB;
